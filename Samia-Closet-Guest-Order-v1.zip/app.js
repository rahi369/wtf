import {initializeApp} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import {getAuth,signInWithEmailAndPassword,signOut,onAuthStateChanged} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import {getFirestore,collection,getDocs,addDoc,doc,updateDoc,deleteDoc,query,orderBy,limit,serverTimestamp} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

const firebaseConfig={
 apiKey:"REPLACE_WITH_YOUR_FIREBASE_API_KEY",
 authDomain:"samia-s-closet-new-8f9d0.firebaseapp.com",
 projectId:"samia-s-closet-new-8f9d0",
 storageBucket:"samia-s-closet-new-8f9d0.firebasestorage.app",
 messagingSenderId:"918050416914",
 appId:"1:918050416914:web:97448621af475b9c42ebcb"
};
const ADMIN="rahihumaun369@gmail.com", PAYMENT_NUMBER="01314652599";
const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app);
let products=[],cart=JSON.parse(localStorage.getItem("sc_cart")||"[]"),cat="all",adminUser=null;
const $=id=>document.getElementById(id),money=n=>"৳"+Number(n||0).toLocaleString("en-BD");
const esc=x=>String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const show=id=>$(id).classList.add("show"),hide=id=>$(id).classList.remove("show");
$("year").textContent=new Date().getFullYear();

document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>b.closest(".modal").classList.remove("show"));
$("adminLink").onclick=e=>{e.preventDefault();adminLogin();};

async function loadProducts(){
 try{const s=await getDocs(query(collection(db,"products"),orderBy("createdAt","desc")));products=s.docs.map(d=>({id:d.id,...d.data()}));}
 catch(e){console.error(e);products=[]}
 renderProducts();
}
function renderProducts(){
 const q=($("search").value||"").toLowerCase();
 const list=products.filter(p=>(cat==="all"||p.category===cat)&&(!q||String(p.name).toLowerCase().includes(q)));
 $("productsGrid").innerHTML=list.length?list.map(p=>`<article class="card"><img src="${esc(p.image||"assets/logo.jpg")}" data-img="${esc(p.image||"assets/logo.jpg")}"><div class="cardBody"><h3>${esc(p.name)}</h3><b>${money(p.price)}</b><p>${esc(p.category||"")} · Stock ${Number(p.stock||0)}</p><div class="actions"><button data-view="${p.id}">VIEW DETAILS</button><button class="primary" data-add="${p.id}">ORDER NOW</button></div></div></article>`).join(""):`<div class="orderRow">No products added yet. Add products from Admin.</div>`;
 document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>addToCart(b.dataset.add));
 document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>details(b.dataset.view));
 document.querySelectorAll("[data-img]").forEach(i=>i.onclick=()=>{show("modal");$("modalContent").innerHTML=`<img src="${i.dataset.img}" style="width:100%;max-height:75vh;object-fit:contain">`;});
}
$("search").oninput=renderProducts;
document.querySelectorAll(".filters button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");cat=b.dataset.cat;renderProducts();});

function addToCart(id){
 const p=products.find(x=>x.id===id); if(!p)return;
 const found=cart.find(x=>x.id===id); if(found)found.qty++; else cart.push({id:p.id,name:p.name,price:Number(p.price||0),image:p.image||"",qty:1});
 saveCart(); alert("Added to bag.");
}
function saveCart(){localStorage.setItem("sc_cart",JSON.stringify(cart));$("cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);}
function details(id){
 const p=products.find(x=>x.id===id);if(!p)return;
 show("modal");$("modalContent").innerHTML=`<img src="${esc(p.image||"assets/logo.jpg")}" style="width:100%;max-height:55vh;object-fit:contain"><h2>${esc(p.name)}</h2><h3>${money(p.price)}</h3><p>${esc(p.description||"No description yet.")}</p><button class="btn wide" id="detailOrder">ORDER NOW</button>`;
 $("detailOrder").onclick=()=>{addToCart(id);hide("modal");openCart();};
}
function openCart(){
 const sub=cart.reduce((a,x)=>a+x.price*x.qty,0);
 show("modal");
 $("modalContent").innerHTML=`<h2>Your Bag</h2>${cart.length?cart.map((x,i)=>`<div class="orderRow"><b>${esc(x.name)}</b><p>${money(x.price)} × ${x.qty} = ${money(x.price*x.qty)}</p><button data-minus="${i}">−</button> <button data-plus="${i}">+</button> <button data-remove="${i}">Remove</button></div>`).join(""):`<p>Your bag is empty.</p>`}<h3>Subtotal: ${money(sub)}</h3>${cart.length?'<button class="btn wide" id="checkoutGo">Checkout</button>':""}`;
 document.querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>{cart[b.dataset.minus].qty--;if(cart[b.dataset.minus].qty<1)cart.splice(b.dataset.minus,1);saveCart();openCart();});
 document.querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>{cart[b.dataset.plus].qty++;saveCart();openCart();});
 document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart.splice(b.dataset.remove,1);saveCart();openCart();});
 $("checkoutGo")?.addEventListener("click",()=>{hide("modal");openCheckout();});
}
$("cartBtn").onclick=openCart;

function openCheckout(){
 if(!cart.length)return;
 $("checkoutMsg").textContent="";
 $("checkoutForm").reset();
 $("payment").value="COD"; $("onlineBox").hidden=true;
 updateTotal();show("checkout");
}
function updateTotal(){
 const sub=cart.reduce((a,x)=>a+x.price*x.qty,0);
 const area=($("cArea").value||"").toLowerCase();
 const delivery=area.includes("moulvibazar")||area.includes("মৌলভীবাজার")?50:150;
 $("checkoutTotal").textContent=`Subtotal ${money(sub)} + Delivery ${money(delivery)} = ${money(sub+delivery)}`;
}
$("cArea").oninput=updateTotal;
$("payment").onchange=()=>{$("onlineBox").hidden=$("payment").value==="COD";};
$("copyPay").onclick=async()=>{try{await navigator.clipboard.writeText(PAYMENT_NUMBER);$("copyPay").textContent="Copied";}catch{}};

function compress(file){
 return new Promise((resolve,reject)=>{
  const r=new FileReader();r.onload=()=>{const img=new Image();img.onload=()=>{
   const max=1000,scale=Math.min(1,max/img.width),c=document.createElement("canvas");c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext("2d").drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL("image/jpeg",.58));
  };img.src=r.result;};r.onerror=reject;r.readAsDataURL(file);
 });
}
$("checkoutForm").onsubmit=async e=>{
 e.preventDefault();$("checkoutMsg").textContent="Sending order…";
 const sub=cart.reduce((a,x)=>a+x.price*x.qty,0),area=$("cArea").value.trim(),delivery=(area.toLowerCase().includes("moulvibazar")||area.includes("মৌলভীবাজার"))?50:150;
 const payment=$("payment").value;
 if(payment!=="COD"&&!$("txid").value.trim()){ $("checkoutMsg").textContent="Online payment হলে Transaction ID দিতে হবে.";return; }
 let screenshot="";
 if($("ss").files[0]){try{ screenshot=await compress($("ss").files[0]); }catch{}}
 const orderId="SC-"+Date.now().toString(36).toUpperCase();
 try{
  await addDoc(collection(db,"orders"),{
   orderId,customerName:$("cName").value.trim(),phone:$("cPhone").value.trim(),address:$("cAddress").value.trim(),area,
   paymentMethod:payment,txid:$("txid").value.trim(),paymentScreenshot:screenshot,
   items:cart.map(x=>({id:x.id,name:x.name,price:x.price,qty:x.qty})),subtotal:sub,discount:0,delivery,total:sub+delivery,
   status:"Pending",position:null,createdAt:serverTimestamp(),updatedAt:serverTimestamp()
  });
  cart=[];saveCart();hide("checkout");$("successText").textContent=`Order ID: ${orderId} · Status: Pending`;show("success");
 }catch(err){console.error(err);$("checkoutMsg").textContent="Order পাঠানো যায়নি: "+err.message;}
};

async function adminLogin(){
 show("modal");
 $("modalContent").innerHTML=`<h2>Private Admin Login</h2><p class="muted">Customer login/signup নেই। এই login শুধু owner-এর জন্য.</p><input id="adminEmail" type="email" placeholder="Admin email"><input id="adminPass" type="password" placeholder="Password"><p id="adminMsg" class="error"></p><button class="btn wide" id="adminLoginBtn">Login</button>`;
 $("adminLoginBtn").onclick=async()=>{
  try{
   const cred=await signInWithEmailAndPassword(auth,$("adminEmail").value.trim(),$("adminPass").value);
   if(cred.user.email.toLowerCase()!==ADMIN){await signOut(auth);throw new Error("Unauthorized admin account.");}
   adminUser=cred.user;adminPanel();
  }catch(e){$("adminMsg").textContent=e.message;}
 };
}
onAuthStateChanged(auth,u=>{adminUser=(u&&u.email?.toLowerCase()===ADMIN)?u:null;});

async function adminPanel(){
 $("modalContent").innerHTML=`<h2>Private Control Room</h2><p>Logged in as ${esc(ADMIN)}</p><div class="adminGrid">
 <form id="productForm"><h3>Add Product</h3><input id="pn" required placeholder="Product name"><input id="pp" required type="number" min="0" placeholder="Price"><select id="pc"><option>Women</option><option>Boys/Men</option></select><input id="pi" placeholder="Image URL"><input id="ps" required type="number" min="0" value="1" placeholder="Stock"><textarea id="pd" placeholder="Description"></textarea><button class="btn wide">Add Product</button></form>
 <div><h3>Products</h3><div id="adminProducts"></div></div>
 <div><h3>Orders</h3><div id="adminOrders"></div></div>
 </div><button id="adminLogout" class="wide">Logout</button>`;
 $("productForm").onsubmit=async e=>{e.preventDefault();await addDoc(collection(db,"products"),{name:$("pn").value.trim(),price:Number($("pp").value),category:$("pc").value,image:$("pi").value.trim()||"assets/logo.jpg",stock:Number($("ps").value),description:$("pd").value.trim(),createdAt:serverTimestamp(),updatedAt:serverTimestamp()});e.target.reset();await loadProducts();await refreshAdmin();};
 $("adminLogout").onclick=async()=>{await signOut(auth);adminUser=null;hide("modal");};
 await refreshAdmin();
}
async function refreshAdmin(){
 const ps=await getDocs(query(collection(db,"products"),orderBy("createdAt","desc")));
 $("adminProducts").innerHTML=ps.docs.map(d=>`<div class="orderRow"><b>${esc(d.data().name)}</b> · ${money(d.data().price)} · stock ${d.data().stock} <button data-pdel="${d.id}">Delete</button></div>`).join("")||"<p>No products.</p>";
 document.querySelectorAll("[data-pdel]").forEach(b=>b.onclick=async()=>{await deleteDoc(doc(db,"products",b.dataset.pdel));await loadProducts();await refreshAdmin();});
 const os=await getDocs(query(collection(db,"orders"),orderBy("createdAt","desc"),limit(100)));
 $("adminOrders").innerHTML=os.docs.map(d=>{
  const o=d.data();return `<div class="orderRow"><b>${esc(o.orderId)}</b><p>${esc(o.customerName)} · ${esc(o.phone)} · ${money(o.total)}</p><p>${esc(o.area)} · ${esc(o.paymentMethod)}${o.txid?` · TxID: ${esc(o.txid)}`:""}</p><select data-status="${d.id}">${["Pending","Confirmed","Processing","Shipped","Delivered","Cancelled"].map(s=>`<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select><input data-position="${d.id}" type="number" min="1" placeholder="Queue position" value="${o.position||""}">${o.paymentScreenshot?`<details><summary>Payment Screenshot</summary><img src="${o.paymentScreenshot}" style="max-width:100%"></details>`:""}</div>`;
 }).join("")||"<p>No orders yet.</p>";
 document.querySelectorAll("[data-status]").forEach(s=>s.onchange=async()=>updateDoc(doc(db,"orders",s.dataset.status),{status:s.value,updatedAt:serverTimestamp()}));
 document.querySelectorAll("[data-position]").forEach(i=>i.onchange=async()=>updateDoc(doc(db,"orders",i.dataset.position),{position:Number(i.value)||null,updatedAt:serverTimestamp()}));
}
loadProducts();saveCart();